package co.edu.poli.act2;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringbootObjectApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringbootObjectApplication.class, args);
	}

}
