package co.edu.poli.act2;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringbootObjectApplicationTests {

	@Test
	void contextLoads() {
	}

}
