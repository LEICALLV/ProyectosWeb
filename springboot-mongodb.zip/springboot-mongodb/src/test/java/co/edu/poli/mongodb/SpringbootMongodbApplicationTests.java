package co.edu.poli.mongodb;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringbootMongodbApplicationTests {

	@Test
	void contextLoads() {
	}

}
